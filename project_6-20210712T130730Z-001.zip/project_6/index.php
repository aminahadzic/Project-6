<?php include('server.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apartmani Brčko</title>

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <link rel = "stylesheet" href = "style.css">
    <script src="project_6.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://kit.fontawesome.com/95dc93da07.js"></script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
</head>
<body>
    <main>
        <header>
          <div class="flex container">
            <a id="logo" href="#"> Apartmani Brčko
            </a>
            <nav>
              <button id="nav-toggle" class="hamburger-menu">
                <span class="strip"></span>
                <span class="strip"></span>
                <span class="strip"></span>
              </button>
    
              <ul id="nav-menu">
                <li><a href="index.html" class="active">Home</a></li>
                <li><a href="properties.html">Properties</a></li>
                <li><a href="#index.html">About</a></li>
                <li><a href="index.html">News</a></li>
                <li><a href="#contact">Contact</a></li>
                <li id="close-flyout"><span class="fas fa-times"></span></li>
              </ul>
            </nav>
          </div>
        </header>
        <div id="logout_option">
          <?php if (isset($_SESSION['success'])): ?>
          <div>
            <h3>
              <?php echo $_SESSION['success'];
              unset($_SESSION['success']);
              ?>
            </h3>
          </div>
          <?php endif ?>

          <?php if (isset($_SESSION["username"])): ?>
          <p><?php echo $_SESSION['username']; ?></p>
          <p id="logout_option"><a href="index.html?logout='1">Logout</a></p>
          <?php endif ?>
        </div>
    
        <section>
          <div>
            <img src="Untitled11_20210108195755.png" alt="" id="logo_img">
          </div>
        </section>
    
        <section id="images_intro">
          <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img class="d-block w-100" src="building2.jpg" alt="First slide">
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="building3.jpg" alt="Second slide">
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="room1.jpg" alt="Third slide">
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
        </section>
        <div>
          <p id="intro_p">Welcome to Apartmani Brčko web page! This website will help You find nearby apartments for renting, either 1 day or monthly renting. We have variety of apartments ranging from cheap ones to luxurious ones. If You have any questions, contact us please in the form below!</p>
        </div>
        <section id="feature_card">
        <div class="card text-center">
          <div class="card-header">
            Featured
          </div>
          <div class="card-body">
            <h5 class="card-title">Pogledaj naš najpopularniji stan!</h5>
            <p class="card-text">Svaki mjesec biramo stan koji je među najboljima i stavljamo ga na našu početnu stranicu.</p>
            <a href="property1.html" class="btn btn-primary" id="button_go">Pogledaj!</a>
          </div>
          <div class="card-footer text-muted">
            Prije 2 dana
          </div>
        </div>
        </section>
      <section id="contact">
        <div class="container">
          <h2>Contact</h2>
    
          <div id="form-container">
            <h3>Kontaktiraj naše agente!</h3>
            <form>
              <label for="name">Ime</label>
              <input type="text" id="name" />
    
              <label for="email">Email</label>
              <input type="text" id="email" />
    
              <label for="phone">Telefon</label>
              <input type="text" id="phone" />
    
              <label for="message">Poruka</label>
              <textarea id="message">Zainteresovan sam za iznajmljivanje stana...</textarea>
    
              <button class="rounded">Contact Agent</button>
            </form>
          </div>
        </div>
      </section>
      <a href="#images_intro" class="button1">Vrati se na početak</a>
    
      <footer>
        <div class="flex container">
          <div class="footer-about">
            <h5>About Apartmani Brčko</h5>
            <p>This agency has been one of the leading ones in Brčko for a long time, since 2000. We are proud of our ucstomer service as well as affordable prices. </p>
          </div>
    
          <div class="footer-quick-links">
            <h5>Quick Links</h5>
            <ul>
              <li><a href="#">O nama</a></li>
              <li><a href="#">Usluge</a></li>
              <li><a href="#">Testimonials</a></li>
              <li><a href="#">Contact Us</a></li>
            </ul>
          </div>
    
          <div class="footer-subscribe">
            <h5>Subscribe to our Newsletter</h5>
            <div id="subscribe-container">
              <input type="text" placeholder="Enter Email" />
              <button class="right-rounded">Send</button>
            </div>
    
            <h5 class="follow-us">Follow Us</h5>
            <ul>
              <li><a href="#"><span class="fab fa-facebook-f"></span></a></li>
              <li><a href="#"><span class="fab fa-twitter"></span></a></li>
              <li><a href="#"><span class="fab fa-instagram"></span></a></li>
              <li><a href="#"><span class="fab fa-linkedin-in"></span></a></li>
            </ul>
          </div>
        </div>
    
        <small>
          Copyright &copy; 2020 All rights reserved |Apartments Brčko.
        </small>
      </footer> 
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>