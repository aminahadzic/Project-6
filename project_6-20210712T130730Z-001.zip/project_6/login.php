<?php include('server.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Register</title>
</head>
<body>
    <div class="register-form">
        <h2>Log in</h2>
    </div>

    <form method="post" action="login.php" id="registration_form2">
    <?php include('errors.php'); ?>
        <div class="input-group">
            <label for="">Username</label>
            <input type="text" name="username">
        </div>

        <div class="input-group">
            <label for="">Password</label>
            <input type="password" name="password">
        </div>

        <div class="input-group">
            <button type="submit" name="register" class="btn">Sign up</button>
        </div>
        <p>Not a member yet? <a href="register.php">Register</a></p>
    </form>
</body>
</html>